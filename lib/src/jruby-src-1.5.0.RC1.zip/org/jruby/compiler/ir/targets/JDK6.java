package org.jruby.compiler.ir.targets;

// This class represents JDK6 as the compiler target
// JDK6 has no support for invokedynamic
public class JDK6 extends JVM
{
}
