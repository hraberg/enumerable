package org.jruby.compiler.ir.operands;

public class Symbol extends Reference
{
   public Symbol(String n) { super(n); }
}
