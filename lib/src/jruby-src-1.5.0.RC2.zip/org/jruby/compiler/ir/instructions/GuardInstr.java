package org.jruby.compiler.ir.instructions;

import org.jruby.compiler.ir.Operation;

// Not used anywhere right now!
public class GuardInstr extends NoOperandInstr
{
    public GuardInstr(Operation op) { super(op); }
}
